import React, { useState, useEffect } from 'react';

function App() {
  return (
    <h1>Hello events</h1>
  )
}

export default App;