import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <h1>Welcome to the course!</h1>
    )
  }
}

export default App;
