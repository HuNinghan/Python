import React, { useState } from 'react';

function App() {
  console.log(useState(false))

  return (
    <button>
      My text
    </button>
  )
}

export default App;